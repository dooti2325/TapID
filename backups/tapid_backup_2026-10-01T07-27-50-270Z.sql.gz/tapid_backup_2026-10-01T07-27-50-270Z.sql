-- MySQL dump 10.13  Distrib 5.7.44, for Win64 (x86_64)
--
-- Host: localhost    Database: tapid
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `rfid_card_id` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('present','late','absent') COLLATE utf8mb4_unicode_ci DEFAULT 'present',
  `manual_override` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attendance` (`session_id`,`student_id`),
  KEY `rfid_card_id` (`rfid_card_id`),
  KEY `idx_attendance_session` (`session_id`),
  KEY `idx_attendance_student` (`student_id`),
  KEY `idx_attendance_timestamp` (`timestamp`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `attendance_sessions` (`id`),
  CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `attendance_ibfk_3` FOREIGN KEY (`rfid_card_id`) REFERENCES `rfid_cards` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (1,1,2,2,'2026-09-26 16:25:39','present',0),(2,1,3,3,'2026-09-26 16:25:39','present',0),(3,1,4,4,'2026-09-26 16:25:39','present',0),(4,1,5,5,'2026-09-26 16:25:39','present',0),(5,1,6,NULL,'2026-09-26 16:25:39','present',0),(6,1,7,NULL,'2026-09-26 16:25:39','present',0),(7,1,8,NULL,'2026-09-26 16:25:39','present',0),(8,1,9,NULL,'2026-09-26 16:25:39','present',0),(9,1,10,NULL,'2026-09-26 16:25:39','present',0),(10,1,11,NULL,'2026-09-26 16:25:39','present',0),(11,1,12,NULL,'2026-09-26 16:25:39','present',0),(12,1,13,NULL,'2026-09-26 16:25:39','present',0),(13,1,14,NULL,'2026-09-26 16:25:39','present',0),(14,1,15,NULL,'2026-09-26 16:25:39','present',0),(15,1,16,NULL,'2026-09-26 16:25:39','present',0),(16,1,19,NULL,'2026-09-26 16:25:39','present',0),(17,1,20,NULL,'2026-09-26 16:25:39','present',0),(18,1,21,NULL,'2026-09-26 16:25:39','present',0),(19,1,22,NULL,'2026-09-26 16:25:39','present',0),(20,1,23,NULL,'2026-09-26 16:25:39','present',0),(21,1,24,NULL,'2026-09-26 16:25:39','present',0),(22,1,25,NULL,'2026-09-26 16:25:39','present',0),(23,1,26,NULL,'2026-09-26 16:25:39','present',0),(24,1,27,NULL,'2026-09-26 16:25:39','present',0),(25,1,28,NULL,'2026-09-26 16:25:39','present',0),(33,3,2,2,'2026-09-26 17:40:06','present',0),(35,5,2,2,'2026-09-26 17:41:13','present',0),(37,6,2,2,'2026-09-26 17:42:07','present',0),(39,7,2,2,'2026-09-26 17:48:14','present',0),(40,8,2,2,'2026-10-01 11:12:22','present',0);
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_sessions`
--

DROP TABLE IF EXISTS `attendance_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timetable_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `classroom_id` int(11) NOT NULL,
  `session_date` date NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` enum('active','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `timetable_id` (`timetable_id`),
  KEY `subject_id` (`subject_id`),
  KEY `classroom_id` (`classroom_id`),
  KEY `idx_attendance_sessions_status` (`status`),
  KEY `idx_attendance_sessions_faculty` (`faculty_id`),
  KEY `idx_attendance_sessions_date` (`session_date`),
  CONSTRAINT `attendance_sessions_ibfk_1` FOREIGN KEY (`timetable_id`) REFERENCES `timetable` (`id`) ON DELETE SET NULL,
  CONSTRAINT `attendance_sessions_ibfk_2` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `attendance_sessions_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  CONSTRAINT `attendance_sessions_ibfk_4` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_sessions`
--

LOCK TABLES `attendance_sessions` WRITE;
/*!40000 ALTER TABLE `attendance_sessions` DISABLE KEYS */;
INSERT INTO `attendance_sessions` VALUES (1,2,1,2,1,'2026-09-26','2026-09-26 16:10:39','2026-09-26 17:10:39','completed'),(2,2,1,2,1,'2026-09-26','2026-09-26 16:19:19','2026-09-26 17:19:19','completed'),(3,NULL,9,1,1,'2026-09-26','2026-09-26 17:39:19','2026-09-26 17:41:13','completed'),(4,NULL,9,1,1,'2026-09-26','2026-09-26 17:40:06','2026-09-26 17:40:06','completed'),(5,NULL,9,1,1,'2026-09-26','2026-09-26 17:41:13','2026-09-26 17:41:13','completed'),(6,NULL,9,1,1,'2026-09-26','2026-09-26 17:42:07','2026-09-26 17:42:07','completed'),(7,NULL,9,1,1,'2026-09-26','2026-09-26 17:48:14','2026-09-26 17:48:14','completed'),(8,NULL,9,1,1,'2026-10-01','2026-10-01 11:12:22','2026-10-01 11:12:22','completed');
/*!40000 ALTER TABLE `attendance_sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`tapid_user`@`localhost`*/ /*!50003 TRIGGER after_session_start
AFTER INSERT ON attendance_sessions
FOR EACH ROW
BEGIN
    UPDATE devices 
    SET status = 'online' 
    WHERE classroom_id = NEW.classroom_id AND status != 'revoked';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`tapid_user`@`localhost`*/ /*!50003 TRIGGER after_session_end
AFTER UPDATE ON attendance_sessions
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' AND OLD.status = 'active' THEN
        UPDATE devices 
        SET status = 'offline' 
        WHERE classroom_id = NEW.classroom_id AND status != 'revoked';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'SYSTEM_INITIALIZATION','SYSTEM',NULL,'Database seeded with Section G roster, timetable, faculty, and classrooms','2026-09-26 17:10:39'),(2,1,'HARDWARE_TERMINAL_CONFIGURED','DEVICE',NULL,'Configured ESP32 terminals for C-102 and C-117','2026-09-26 17:10:39'),(3,1,'SYSTEM_INITIALIZATION','SYSTEM',NULL,'Database seeded with Section G roster, timetable, faculty, and classrooms','2026-09-26 17:19:19'),(4,1,'HARDWARE_TERMINAL_CONFIGURED','DEVICE',NULL,'Configured ESP32 terminals for C-102 and C-117','2026-09-26 17:19:19'),(5,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:39:19'),(6,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:39:19'),(7,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/start, Body Keys: subject_name,room_number','2026-09-26 17:39:19'),(8,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:40:06'),(9,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:40:06'),(10,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/start, Body Keys: subject_name,room_number','2026-09-26 17:40:06'),(11,NULL,'POST_ATTENDANCE','API_CALL',NULL,'Path: /api/attendance/record, Body Keys: rfid_uid,mac_address','2026-09-26 17:40:06'),(12,1,'REVOKE_CARD','rfid_cards',NULL,'Revoked card UID: 88:E1:90:3F','2026-09-26 17:40:06'),(13,1,'POST_REVOCATION','API_CALL',NULL,'Path: /api/revocation/card, Body Keys: uid,reason','2026-09-26 17:40:06'),(14,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/4/end, Body Keys: ','2026-09-26 17:40:06'),(15,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:41:13'),(16,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:41:13'),(17,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/start, Body Keys: subject_name,room_number','2026-09-26 17:41:13'),(18,NULL,'POST_ATTENDANCE','API_CALL',NULL,'Path: /api/attendance/record, Body Keys: rfid_uid,mac_address','2026-09-26 17:41:13'),(19,1,'REVOKE_CARD','rfid_cards',NULL,'Revoked card UID: 88:E1:90:3F','2026-09-26 17:41:13'),(20,1,'POST_REVOCATION','API_CALL',NULL,'Path: /api/revocation/card, Body Keys: uid,reason','2026-09-26 17:41:13'),(21,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/5/end, Body Keys: ','2026-09-26 17:41:13'),(22,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:42:07'),(23,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:42:07'),(24,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/start, Body Keys: subject_name,room_number','2026-09-26 17:42:07'),(25,NULL,'POST_ATTENDANCE','API_CALL',NULL,'Path: /api/attendance/record, Body Keys: rfid_uid,mac_address','2026-09-26 17:42:07'),(26,1,'REVOKE_CARD','rfid_cards',NULL,'Revoked card UID: 88:E1:90:3F','2026-09-26 17:42:07'),(27,1,'POST_REVOCATION','API_CALL',NULL,'Path: /api/revocation/card, Body Keys: uid,reason','2026-09-26 17:42:07'),(28,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/6/end, Body Keys: ','2026-09-26 17:42:07'),(29,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:48:14'),(30,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-09-26 17:48:14'),(31,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/start, Body Keys: subject_name,room_number','2026-09-26 17:48:14'),(32,NULL,'POST_ATTENDANCE','API_CALL',NULL,'Path: /api/attendance/record, Body Keys: rfid_uid,mac_address','2026-09-26 17:48:14'),(33,1,'REVOKE_CARD','rfid_cards',NULL,'Revoked card UID: 88:E1:90:3F','2026-09-26 17:48:14'),(34,1,'POST_REVOCATION','API_CALL',NULL,'Path: /api/revocation/card, Body Keys: uid,reason','2026-09-26 17:48:14'),(35,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/7/end, Body Keys: ','2026-09-26 17:48:14'),(36,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-10-01 11:12:22'),(37,NULL,'POST_AUTH','API_CALL',NULL,'Path: /api/auth/login, Body Keys: email,password','2026-10-01 11:12:22'),(38,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/start, Body Keys: subject_name,room_number','2026-10-01 11:12:22'),(39,NULL,'POST_ATTENDANCE','API_CALL',NULL,'Path: /api/attendance/record, Body Keys: rfid_uid,mac_address','2026-10-01 11:12:22'),(40,1,'REVOKE_CARD','rfid_cards',NULL,'Revoked card UID: 88:E1:90:3F','2026-10-01 11:12:22'),(41,1,'POST_REVOCATION','API_CALL',NULL,'Path: /api/revocation/card, Body Keys: uid,reason','2026-10-01 11:12:22'),(42,2,'POST_SESSION','API_CALL',NULL,'Path: /api/session/8/end, Body Keys: ','2026-10-01 11:12:22');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classrooms`
--

DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classrooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `building` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_number` (`room_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classrooms`
--

LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
INSERT INTO `classrooms` VALUES (1,'C-102','Academic Block C (Theory)'),(2,'C-117','Academic Block C (Lab)'),(3,'Ground','Sports Ground');
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classroom_id` int(11) DEFAULT NULL,
  `status` enum('online','offline','revoked') COLLATE utf8mb4_unicode_ci DEFAULT 'offline',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mac_address` (`mac_address`),
  KEY `classroom_id` (`classroom_id`),
  CONSTRAINT `devices_ibfk_1` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (1,'24:0A:C4:00:00:01',1,'offline'),(2,'24:0A:C4:00:00:02',2,'online'),(3,'24:0A:C4:00:00:03',NULL,'offline');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `faculty_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES (1,3,'Ashish Trivedi (AT)','+91 98765 43221','Computer Science & Engineering',NULL),(2,4,'Chetram Thakur (CT)','+91 98765 43222','Computer Science & Engineering',NULL),(3,5,'Dr. Sumalata Bhandari (SB)','+91 98765 43223','Computer Science & Engineering',NULL),(4,6,'Dr. Trupti Meshram (TM)','+91 98765 43224','Computer Science & Engineering',NULL),(5,7,'Amol Dhankar (AD)','+91 98765 43225','Computer Science & Engineering',NULL),(6,8,'Prachi Jain (PSJ)','+91 98765 43226','Computer Science & Engineering',NULL),(7,9,'Reena Dewangan','+91 98765 43227','Fuzzy Logic',NULL),(8,1,'System Administrator','+91 98765 43210','Administration',NULL),(9,2,'Prof. Demo Faculty','+91 98765 43220','Computer Science & Engineering',NULL);
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rfid_cards`
--

DROP TABLE IF EXISTS `rfid_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rfid_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `status` enum('active','revoked','lost') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `issued_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `rfid_cards_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rfid_cards`
--

LOCK TABLES `rfid_cards` WRITE;
/*!40000 ALTER TABLE `rfid_cards` DISABLE KEYS */;
INSERT INTO `rfid_cards` VALUES (1,'04:A2:8B:1A',1,'active','2026-09-26 11:40:39'),(2,'14:F2:3C:99',2,'active','2026-09-26 11:40:39'),(3,'3A:BC:D1:42',3,'active','2026-09-26 11:40:39'),(4,'88:E1:90:3F',4,'revoked','2026-09-26 11:40:39'),(5,'24:0A:C4:01',5,'active','2026-09-26 11:40:39'),(6,'24:0A:C4:00',17,'active','2026-09-26 11:40:39'),(7,'24:0A:C4:02',18,'active','2026-09-26 11:40:39'),(8,'0B:CC:DD:EE',58,'active','2026-09-26 11:40:39');
/*!40000 ALTER TABLE `rfid_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_section` (`name`,`branch`,`semester`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (4,'CS-Core','Computer Science',5),(5,'CS-D','Computer Science',7),(2,'G1 (Roll 1-33)','Computer Science',5),(3,'G2 (Roll 34+)','Computer Science',5),(1,'Section G','Computer Science',5);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enrollment_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `enrollment_number` (`enrollment_number`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_students_section` (`section_id`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `students_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,10,'Shantanu Yashwant Raut','GHRUA23011060140',2,'2026-09-26 11:40:39'),(2,NULL,'DIVYANSH MANUKANT GADEKAR','GHRUA23011060170',2,'2026-09-26 11:40:39'),(3,NULL,'VEDANT MANISH BAVARIA','GHRUA23011060205',2,'2026-09-26 11:40:39'),(4,NULL,'SAMIKSHA PRABHAKAR MOHITKAR','GHRUA23011060250',2,'2026-09-26 11:40:39'),(5,NULL,'SANSKAR LAXMAN GADDEWAR','GHRUA23011060258',2,'2026-09-26 11:40:39'),(6,NULL,'SHREYA ANIL MAHETKAR','GHRUA23011060273',2,'2026-09-26 11:40:39'),(7,NULL,'SHRUTI TULSHIRAM KAWALE','GHRUA23011060275',2,'2026-09-26 11:40:39'),(8,NULL,'SUYASH SUNILRAO HANUMANTE','GHRUA23011060283',2,'2026-09-26 11:40:39'),(9,NULL,'TRUPTI DHIRAJ SEWARE','GHRUA23011060289',2,'2026-09-26 11:40:39'),(10,NULL,'VEDANT GOPAL MANKAR','GHRUA23011060297',2,'2026-09-26 11:40:39'),(11,NULL,'VEDANT MOHAN WANKHEDE','GHRUA23011060298',2,'2026-09-26 11:40:39'),(12,NULL,'VEDANT SUNIL DURGE','GHRUA23011060300',2,'2026-09-26 11:40:39'),(13,NULL,'YASH NAGESHWAR KARME','GHRUA23011060309',2,'2026-09-26 11:40:39'),(14,NULL,'ADITYA BHASKAR DARNE','GHRUA23011060317',2,'2026-09-26 11:40:39'),(15,NULL,'ANURAG ATUL JOSHI','GHRUA23011060322',2,'2026-09-26 11:40:39'),(16,NULL,'AYUSH RAJESH KALAMBE','GHRUA23011060336',2,'2026-09-26 11:40:39'),(17,11,'Dootiballav Gouriprasanna Saha','GHRUA23011060348',2,'2026-09-26 11:40:39'),(18,12,'HARSHAL SUHAS VIDHATE','GHRUA23011060359',2,'2026-09-26 11:40:39'),(19,NULL,'HARSHAL RAMESH VIJAYWAR','GHRUA23011060360',2,'2026-09-26 11:40:39'),(20,NULL,'KASTURI VIVEK AWACHAT','GHRUA23011060389',2,'2026-09-26 11:40:39'),(21,NULL,'KRITIKA JITENDRA PANDEY','GHRUA23011060393',2,'2026-09-26 11:40:39'),(22,NULL,'KUNAL SUDEEP JAIN','GHRUA23011060396',2,'2026-09-26 11:40:39'),(23,NULL,'Nikhil Parmeshwar Netam','GHRUA23011060418',2,'2026-09-26 11:40:39'),(24,NULL,'PRASAD PRASHANT DEO','GHRUA23011060454',2,'2026-09-26 11:40:39'),(25,NULL,'PRASHIT PRABHAT HOKAM','GHRUA23011060455',2,'2026-09-26 11:40:39'),(26,NULL,'KUNALI AMOL PATHRABE','GHRUA23011060457',2,'2026-09-26 11:40:39'),(27,NULL,'Madhur Sudhir Madankar','GHRUA23011060462',2,'2026-09-26 11:40:39'),(28,NULL,'PRATHMESH RAMESH AMLE','GHRUA23011060467',2,'2026-09-26 11:40:39'),(29,NULL,'PRIYANSHU DINESH AMBHORE','GHRUA23011060471',2,'2026-09-26 11:40:39'),(30,NULL,'VEDANT SACHIDANAND WANDHARE','GHRUA23011060500',2,'2026-09-26 11:40:39'),(31,NULL,'DIVYANSH SALIL VERMA','GHRUA23011060571',2,'2026-09-26 11:40:39'),(32,NULL,'PRIYANSHU SWARUPKUMAR KATRE','GHRUA23011060592',2,'2026-09-26 11:40:39'),(33,NULL,'TRISHA NARENDRA TURKAR','GHRUA23011060606',2,'2026-09-26 11:40:39'),(34,NULL,'KSHITIJ JOHNEY DUSHING','GHRUA23011060614',3,'2026-09-26 11:40:39'),(35,NULL,'VEDANT GOPALRAO BIRGADE','GHRUA23011060687',3,'2026-09-26 11:40:39'),(36,NULL,'YASH RAJESH TAMHANKAR','GHRUA23011060688',3,'2026-09-26 11:40:39'),(37,NULL,'PRINCY KAMLESH TABHANE','GHRUA23011060713',3,'2026-09-26 11:40:39'),(38,NULL,'Om Yuwaraj Chandekar','GHRUA23011060725',3,'2026-09-26 11:40:39'),(39,NULL,'Aniket Gajanan Balbudhe','GHRUA23011060780',3,'2026-09-26 11:40:39'),(40,NULL,'RUTUJA RAKESH BHUSARI','GHRUA23011060793',3,'2026-09-26 11:40:39'),(41,NULL,'Prajkta Narendra Wankhede','GHRUA23011060816',3,'2026-09-26 11:40:39'),(42,NULL,'SARTHAK AKHILESH DUBEY','GHRUA23011060819',3,'2026-09-26 11:40:39'),(43,NULL,'KRISHNA SANTOSH MORE','GHRUA23011060837',3,'2026-09-26 11:40:39'),(44,NULL,'SAMPADA DAULATHRAMSINGH BUNDEL','GHRUA23011060840',3,'2026-09-26 11:40:39'),(45,NULL,'AVINASH RAJU MUDE','GHRUA23011060866',3,'2026-09-26 11:40:39'),(46,NULL,'KAUSTUBH KISHOR SAURKAR','GHRUA23011060868',3,'2026-09-26 11:40:39'),(47,NULL,'KRUTEE WASUDEO SHENDE','GHRUA23011060870',3,'2026-09-26 11:40:39'),(48,NULL,'KUNAL RAJU JIWTODE','GHRUA23011060872',3,'2026-09-26 11:40:39'),(49,NULL,'PRATIK LAKHANLAL GHORMARE','GHRUA23011060873',3,'2026-09-26 11:40:39'),(50,NULL,'HARSHAL SURENDRA DOIFODE','GHRUA23011060889',3,'2026-09-26 11:40:39'),(51,NULL,'ANJALI RAMESH REWATKAR','GHRUA23011060893',3,'2026-09-26 11:40:39'),(52,NULL,'PRACHI SANJAY DHOTE','GHRUA23011060894',3,'2026-09-26 11:40:39'),(53,NULL,'PUSHPAK RAJKUMAR IKHAR','GHRUA23011060907',3,'2026-09-26 11:40:39'),(54,NULL,'TRUPTI PRAVIN ZILPE','GHRUA23011060914',3,'2026-09-26 11:40:39'),(55,NULL,'YASH DHANARAJ HATWAR','GHRUA23011060922',3,'2026-09-26 11:40:39'),(56,NULL,'SAKSHI RAJENDRA OZA','GHRUA23011060939',3,'2026-09-26 11:40:39'),(57,NULL,'VEDANT RAJESH WANDHARE','GHRUA23011060972',3,'2026-09-26 11:40:39'),(58,NULL,'KARAN SHIVPRASAD SHAHU','GHRUA23011060981',3,'2026-09-26 11:40:39');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'CD','Compiler Design',5),(2,'CSS','Computer System Security',5),(3,'ES-AI','Ethical & Social Implication of AI',5),(4,'DEV','DevOps: Software Development & IT Operations',5),(5,'AIML','Artificial Intelligence and Machine Learning',5),(6,'PROJECT','Capstone Project Lab',5),(7,'SPORTS','Sports & Athletics',5);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faculty_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `classroom_id` int(11) NOT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_timetable_slot` (`faculty_id`,`subject_id`,`section_id`,`classroom_id`,`day_of_week`,`start_time`),
  KEY `subject_id` (`subject_id`),
  KEY `section_id` (`section_id`),
  KEY `classroom_id` (`classroom_id`),
  KEY `idx_timetable_faculty_day` (`faculty_id`,`day_of_week`),
  CONSTRAINT `timetable_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`),
  CONSTRAINT `timetable_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  CONSTRAINT `timetable_ibfk_3` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  CONSTRAINT `timetable_ibfk_4` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable`
--

LOCK TABLES `timetable` WRITE;
/*!40000 ALTER TABLE `timetable` DISABLE KEYS */;
INSERT INTO `timetable` VALUES (1,2,1,4,1,'Monday','08:05:00','09:00:00'),(2,1,2,4,1,'Monday','09:00:00','09:55:00'),(3,3,3,4,1,'Monday','10:15:00','11:10:00'),(4,5,7,4,3,'Monday','11:10:00','12:05:00'),(5,4,6,4,1,'Monday','12:10:00','14:00:00'),(6,1,2,4,1,'Tuesday','08:05:00','09:00:00'),(7,4,4,4,1,'Tuesday','09:00:00','09:55:00'),(8,2,1,4,1,'Tuesday','10:15:00','11:10:00'),(9,3,3,4,1,'Tuesday','11:10:00','12:05:00'),(10,4,6,4,1,'Tuesday','12:10:00','14:00:00'),(11,3,3,4,1,'Wednesday','08:05:00','09:00:00'),(12,5,5,4,1,'Wednesday','09:00:00','09:55:00'),(13,4,4,4,1,'Wednesday','10:15:00','11:10:00'),(14,1,2,4,1,'Wednesday','11:10:00','12:05:00'),(15,4,6,4,1,'Wednesday','12:10:00','14:00:00'),(16,5,5,4,1,'Thursday','08:05:00','09:00:00'),(17,4,4,4,1,'Thursday','09:00:00','09:55:00'),(18,5,5,4,1,'Thursday','10:15:00','11:10:00'),(19,2,1,4,1,'Thursday','11:10:00','12:05:00'),(20,2,1,2,2,'Thursday','12:10:00','14:00:00'),(21,4,4,4,1,'Friday','08:05:00','09:00:00'),(22,3,3,4,1,'Friday','09:00:00','09:55:00'),(23,6,1,3,1,'Friday','10:15:00','12:05:00'),(24,4,6,4,1,'Friday','12:10:00','14:00:00'),(25,5,7,4,3,'Saturday','08:05:00','09:55:00'),(26,5,7,4,3,'Saturday','10:15:00','14:00:00');
/*!40000 ALTER TABLE `timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','faculty','student') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','admin','2026-09-26 11:40:39'),(2,'faculty@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(3,'ashish.trivedi@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(4,'chetram.thakur@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(5,'sumalata.bhandari@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(6,'trupti.meshram@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(7,'amol.dhankar@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(8,'prachi.jain@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(9,'reenadewangan@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','faculty','2026-09-26 11:40:39'),(10,'student1@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','student','2026-09-26 11:40:39'),(11,'student2@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','student','2026-09-26 11:40:39'),(12,'harshal.vidhate@tapid.edu','$2b$10$E1NSnAY21jNZbxh557eqBe1f6iQSkmxdtmp.OEekmqfx7DFR5k5aC','student','2026-09-26 11:40:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tapid'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-01 12:57:50
